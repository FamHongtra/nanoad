#!/bin/bash

source currfile.sh

clear
realfullpath="/etc/testpath/testpath.conf"
realpathfile="/etc/testpath"
realfile="testpath.conf"

#Initial when get this editor from web application
mkdir -p /etc/nanoad/tmp_repo/etc/testpath
git init /etc/nanoad/tmp_repo &> /dev/null
git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo config user.name "Administrator" &> /dev/null
git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo config user.email "admin@example.com" &> /dev/null
git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo remote add backupversion http://root:project2017@ec2-13-228-10-174.ap-southeast-1.compute.amazonaws.com/root/server01.git

if [[ $filepath == "/etc/testpath/testpath.conf" ]]
then 	clear
	echo "Please wait..."
	cp /etc/testpath/testpath.conf /etc/nanoad/tmp_repo/etc/testpath 
	git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo add . &> /dev/null
	git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo commit -m "$(date +%Y-%m-%d' '%H:%M:%S)" &> /dev/null
	git --git-dir=/etc/nanoad/tmp_repo/.git --work-tree=/etc/nanoad/tmp_repo push -u backupversion master &> /dev/null
	clear
	echo "Done! Your configuration file was saved."
fi

