#!/bin/bash

source currfile.sh

