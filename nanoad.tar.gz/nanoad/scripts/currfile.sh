#!/bin/bash

filename=

filepath=
