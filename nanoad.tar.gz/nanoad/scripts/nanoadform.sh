#!/bin/bash

source currfile.sh

clear


